/*
 * CS-499 Computer Science Capstone
 * Artifact Category: Software Engineering and Design
 * Original Course: IT-145 Foundations in Application Development
 *
 * File: Driver.java
 * Description:
 *   Console-based entry point for the Rescue Animal Management System. Presents
 *   a text menu, collects user input, and calls methods to add and display
 *   rescue animals.
 *
 * Code Review Focus (using CS 499 Code Review Checklist):
 *   - Structure: repeated menu/input code and lack of modular methods
 *   - Documentation: clarity of comments and menu prompts
 *   - Defensive programming: missing input validation and error handling
 *   - Opportunities to refactor toward a JavaFX GUI and persistence layer
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Driver {

    // Core in-memory collections for rescue animals
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();

    public static void main(String[] args) {

        initializeDogList();
        initializeMonkeyList();

        // To implement input validation for the user while navigating the menu,
        // this loop continues to prompt until the user chooses to quit.
        boolean acceptingInput = true;
        Scanner input = new Scanner(System.in);

        do {
            displayMenu();
            String option = input.nextLine().trim().toLowerCase();

            switch (option) {
                case "1": // New Dog Intake
                    intakeNewDog(input);
                    break;

                case "2": // New Monkey Intake
                    intakeNewMonkey(input);
                    break;

                case "3": // Reserve Animal
                    reserveAnimal(input);
                    break;

                case "4": // Print list of all dogs
                    printAnimals("dog");
                    break;

                case "5": // Print list of all monkeys
                    printAnimals("monkey");
                    break;

                case "6": // Print list of all available (non-reserved) animals
                    printAnimals("available");
                    break;

                case "q": // Quit
                    acceptingInput = false;
                    break;

                default: // Feedback stating the user input does not match menu options
                    System.out.println("Invalid entry. Please enter a valid menu option.");
                    break;
            }
        } while (acceptingInput);

        input.close();
        System.out.println("Exiting Rescue Animal System. Goodbye!");
    }

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }

    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6",
                "05-12-2019", "United States", "intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2",
                "02-03-2020", "United States", "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6",
                "12-12-2019", "Canada", "in service", true, "Canada");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
    }

    // Adds monkeys to a list for testing
    public static void initializeMonkeyList() {
        Monkey monkey1 = new Monkey("Bella", "Guenon", "female", "3", "7.9",
                "20", "16", "12", "05-21-2021", "Canada",
                "Phase I", false, "Canada");
        Monkey monkey2 = new Monkey("Edward", "Squirrel monkey", "male", "4", "2.7",
                "12.5", "9", "16", "03-13-2020", "United States",
                "Phase III", false, "United States");
        Monkey monkey3 = new Monkey("Jacob", "Tamarin", "male", "4", "1.6",
                "9", "7", "1", "01-15-2020", "United States",
                "in service", false, "United States");

        monkeyList.add(monkey1);
        monkeyList.add(monkey2);
        monkeyList.add(monkey3);
    }

    // ================================
    // Enhanced intakeNewDog method
    // Demonstrates centralized validation & defensive programming
    // ================================
    public static void intakeNewDog(Scanner scanner) {

        // Ask for dog name using non-empty validation
        String name = promptNonEmpty(scanner, "What is the dog's name?");

        // Ensure dog is not already in dogList
        for (Dog dog : dogList) {
            if (dog.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis dog is already in our system.\n\n");
                return; // return to menu
            }
        }

        // Gather the rest of the information, validating input as we go
        String breed = promptNonEmpty(scanner, "Enter " + name + "'s breed:");

        // Gender - restrict to a small set of options
        String[] genderOptions = { "male", "female" };
        String gender = promptFromOptions(
                scanner,
                "Enter " + name + "'s gender (male/female):",
                genderOptions
        );

        // Age and weight remain Strings in the underlying model,
        // but we still validate that the user enters something non-empty.
        String age = promptNonEmpty(scanner, "Enter " + name + "'s age in years:");
        String weight = promptNonEmpty(scanner, "Enter " + name + "'s weight in pounds:");

        String acquisitionDate = promptNonEmpty(
                scanner,
                "Enter the date " + name + " was acquired into your care: (MM-DD-YYYY)"
        );

        String acquisitionCountry = promptNonEmpty(
                scanner,
                "Enter the country where " + name + " was acquired:"
        );

        String trainingStatus = promptNonEmpty(
                scanner,
                "Enter " + name + "'s current training status: (\"intake\", \"in service\", \"Phase I/II/III/IV/V\", \"farm\")"
        );

        boolean reserved = promptYesNo(scanner, "Is " + name + " currently reserved?");

        String inServiceCountry = promptNonEmpty(
                scanner,
                "Enter " + name + "'s service country:"
        );

        // Create and add the new dog to dogList
        Dog newDog = new Dog(
                name,
                breed,
                gender,
                age,
                weight,
                acquisitionDate,
                acquisitionCountry,
                trainingStatus,
                reserved,
                inServiceCountry
        );

        dogList.add(newDog);
        System.out.println("\n\nDog \"" + name + "\" has been successfully added to the system.\n\n");
    }

    // ======================================
    // Enhanced intakeNewMonkey method
    // Uses validation helpers and species whitelist
    // ======================================
    public static void intakeNewMonkey(Scanner scanner) {

        // Prompt user for monkey name (non-empty)
        String name = promptNonEmpty(scanner, "Enter the monkey's name:");

        // Validate that this monkey is not already in the system
        for (Monkey monkey : monkeyList) {
            if (monkey.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis monkey is already registered in our system.\n\n");
                return;
            }
        }

        // Species must be one of Monkey.VALID_SPECIES
        String species = promptFromOptions(
                scanner,
                "Enter " + name + "'s species:",
                Monkey.VALID_SPECIES
        );

        // Gender restricted to male/female
        String[] genderOptions = { "male", "female" };
        String gender = promptFromOptions(
                scanner,
                "Enter " + name + "'s gender (male/female):",
                genderOptions
        );

        // The remaining fields must be non-empty input
        String age = promptNonEmpty(scanner, "Enter " + name + "'s age (in years):");
        String weight = promptNonEmpty(scanner, "Enter " + name + "'s weight (in pounds):");
        String height = promptNonEmpty(scanner, "Enter " + name + "'s height (head to toe) in inches:");
        String bodyLength = promptNonEmpty(scanner, "Enter " + name + "'s body length (head to pelvis) in inches:");
        String tailLength = promptNonEmpty(scanner, "Enter " + name + "'s tail length (base to tip) in inches:");

        String acquisitionDate = promptNonEmpty(
                scanner,
                "Enter the date " + name + " was acquired into your care: (MM-DD-YYYY)"
        );

        String acquisitionCountry = promptNonEmpty(
                scanner,
                "Enter the country where " + name + " was acquired:"
        );

        String trainingStatus = promptNonEmpty(
                scanner,
                "Enter " + name + "'s current training status: (\"intake\", \"in service\", \"Phase I/II/III/IV/V\", \"farm\")"
        );

        boolean reserved = promptYesNo(scanner, "Is " + name + " currently reserved?");

        String inServiceCountry = promptNonEmpty(
                scanner,
                "Enter " + name + "'s current service country:"
        );

        // Instantiate and add the new monkey to the monkeyList
        Monkey newMonkey = new Monkey(
                name,
                species,
                gender,
                age,
                weight,
                height,
                bodyLength,
                tailLength,
                acquisitionDate,
                acquisitionCountry,
                trainingStatus,
                reserved,
                inServiceCountry
        );

        monkeyList.add(newMonkey);
        System.out.println("\n\nMonkey \"" + name + "\" has been successfully added to the system.\n\n");
    }

    // Completed reserveAnimal
    // Find and reserve the animal by animal type and in-service country
    public static void reserveAnimal(Scanner scanner) {
        System.out.println("What type of animal would you like to reserve? (\"dog\", \"monkey\")");
        String animalType = scanner.nextLine().trim();

        System.out.println("What country will the animal be in service?");
        String animalServiceCountry = scanner.nextLine().trim();

        // If user requests a dog reservation: sort through all available dogs
        if (animalType.equalsIgnoreCase("dog")) {
            for (Dog dog : dogList) {
                if (dog.getInServiceLocation().equalsIgnoreCase(animalServiceCountry)
                        && !dog.getReserved()) {

                    dog.setReserved(true);
                    dog.setInServiceCountry(animalServiceCountry);

                    System.out.println(dog.getName() + " has been reserved!");
                    return;
                }
            }
        }

        // Sort through all available monkeys
        if (animalType.equalsIgnoreCase("monkey")) {
            for (Monkey monkey : monkeyList) {
                if (monkey.getInServiceLocation().equalsIgnoreCase(animalServiceCountry)
                        && !monkey.getReserved()) {

                    monkey.setReserved(true);
                    monkey.setInServiceCountry(animalServiceCountry);

                    System.out.println(monkey.getName() + " has been reserved!");
                    return;
                }
            }
        }

        System.out.println("Unable to reserve a " + animalType + " from " + animalServiceCountry + " at this time.");
    }

    // Complete printAnimals
    // Included is the animal name, status, acquisition country and if the animal is reserved.
    public static void printAnimals(String outputType) {
        System.out.printf("%-8.15s\t| %-1.15s\t| %-1.15s\t| %s%n%n",
                "Name", "Status", "Acq. Country", "Reserved");

        // Three different outputs for printAnimals() method
        switch (outputType) {
            case "dog": // List of all dogs
                for (Dog dog : dogList) {
                    String name = dog.getName();
                    String status = dog.getTrainingStatus();
                    String acquisitionCountry = dog.getAcquisitionLocation();
                    boolean reserved = dog.getReserved();

                    System.out.printf("%-8.15s\t| %-1.15s\t| %-1.15s\t| %s%n",
                            name, status, acquisitionCountry, reserved);
                }
                break;

            case "monkey": // List of all monkeys
                for (Monkey monkey : monkeyList) {
                    String name = monkey.getName();
                    String status = monkey.getTrainingStatus();
                    String acquisitionCountry = monkey.getAcquisitionLocation();
                    boolean reserved = monkey.getReserved();

                    System.out.printf("%-8.15s\t| %-1.15s\t| %-1.15s\t| %s%n",
                            name, status, acquisitionCountry, reserved);
                }
                break;

            case "available": // Print all available / non-reserved animals in service
                // Dogs
                for (Dog dog : dogList) {
                    String name = dog.getName();
                    String status = dog.getTrainingStatus();
                    String acquisitionCountry = dog.getAcquisitionLocation();
                    boolean reserved = dog.getReserved();

                    boolean available = !reserved && status.equalsIgnoreCase("in service");
                    if (!available) {
                        continue;
                    }

                    System.out.printf("%-8.15s\t| %-1.15s\t| %-1.15s\t| %s%n",
                            name, status, acquisitionCountry, reserved);
                }

                // Monkeys
                for (Monkey monkey : monkeyList) {
                    String name = monkey.getName();
                    String status = monkey.getTrainingStatus();
                    String acquisitionCountry = monkey.getAcquisitionLocation();
                    boolean reserved = monkey.getReserved();

                    boolean available = !reserved && status.equalsIgnoreCase("in service");
                    if (!available) {
                        continue;
                    }

                    System.out.printf("%-8.15s\t| %-1.15s\t| %-1.15s\t| %s%n",
                            name, status, acquisitionCountry, reserved);
                }
                break;
        }
    }

    // ================================
    // CS-499 Enhancement Helper Methods
    // Centralized input validation & defensive programming
    // ================================

    /**
     * Prompt the user until they enter a non-empty line of text.
     */
    private static String promptNonEmpty(Scanner scanner, String prompt) {
        String value;
        do {
            System.out.println(prompt);
            value = scanner.nextLine().trim();
            if (value.isEmpty()) {
                System.out.println("Input cannot be blank. Please try again.");
            }
        } while (value.isEmpty());
        return value;
    }

    /**
     * Prompt until the user enters a value that matches one of the allowed options
     * (case-insensitive). Returns the value using the exact casing the user entered.
     */
    private static String promptFromOptions(Scanner scanner, String prompt, String[] allowedOptions) {
        while (true) {
            System.out.println(prompt);
            String value = scanner.nextLine().trim();

            for (String option : allowedOptions) {
                if (option.equalsIgnoreCase(value)) {
                    return value; // valid choice
                }
            }

            System.out.println("Invalid entry. Valid options are:");
            for (String option : allowedOptions) {
                System.out.println("  - " + option);
            }
        }
    }

    /**
     * Prompt the user for a yes/no question. Returns true for Y, false for N.
     */
    private static boolean promptYesNo(Scanner scanner, String prompt) {
        while (true) {
            System.out.println(prompt + " (Y/N)");
            String value = scanner.nextLine().trim();

            if (value.equalsIgnoreCase("Y")) {
                return true;
            } else if (value.equalsIgnoreCase("N")) {
                return false;
            } else {
                System.out.println("Please enter Y or N.");
            }
        }
    }
}

/*
 * CS-499 Enhancement Plan Notes
 *   - Implemented robust input validation and helper methods
 *   - Refactored intakeNewDog and intakeNewMonkey to reduce duplication
 *   - Future work: Replace the console menu with a JavaFX GUI controller
 *   - Future work: Connect to a persistence mechanism (such as JSON or a database)
 */
