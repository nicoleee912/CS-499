/*
 * CS-499 Computer Science Capstone
 * Artifact Category: Software Engineering and Design
 * Original Course: IT-145 Foundations in Application Development
 *
 * File: Dog.java
 * Description:
 *   Dog subclass of RescueAnimal representing canine rescue animals available for
 *   training or deployment. Adds dog-specific attributes as needed.
 *
 * Code Review Focus:
 *   - Consistency with the RescueAnimal base class
 *   - Clear constructor usage and initialization of fields
 *   - Readability and maintainability of dog-specific behavior
 */

public class Dog extends RescueAnimal {

    // Instance variable
    private String breed;

    // Constructor
    public Dog(String name, String breed, String gender, String age,
    String weight, String acquisitionDate, String acquisitionCountry,
	String trainingStatus, boolean reserved, String inServiceCountry) {
        setName(name);
        setBreed(breed);
        setGender(gender);
        setAge(age);
        setWeight(weight);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionLocation(acquisitionCountry);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);

    }

    // Accessor Method
    public String getBreed() {
        return breed;
    }

    // Mutator Method
    public void setBreed(String dogBreed) {
        breed = dogBreed;
    }

}

/*
 * CS-499 Enhancement Plan Notes
 *   - Verify that all dog-specific fields are necessary and documented
 *   - Ensure constructor and setters validate input where appropriate
 */
