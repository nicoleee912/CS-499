/*
 * CS-499 Computer Science Capstone
 * Artifact Category: Software Engineering and Design
 * Original Course: IT-145 Foundations in Application Development
 *
 * File: Driver.java
 * Description:
 *   Console-based entry point for the Rescue Animal Management System. Presents
 *   a text menu, collects user input, and calls methods to add and display
 *   rescue animals.
 *
 * Code Review Focus (using CS 499 Code Review Checklist):
 *   - Structure: repeated menu/input code and lack of modular methods
 *   - Documentation: clarity of comments and menu prompts
 *   - Defensive programming: missing input validation and error handling
 *   - Opportunities to refactor toward a JavaFX GUI and persistence layer
 */


import java.util.ArrayList;
import java.util.Scanner;

public class Driver {
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    // Instance variables (if needed)
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();

    public static void main(String[] args) {


        initializeDogList();
        initializeMonkeyList();
        
        //To implement input validation for the user while navigating the menu,
        //I will use a do-while loop that takes appropriate action from the input.
        
        boolean acceptingInput = true;
        Scanner input = new Scanner(System.in);
        
        do {
        	displayMenu();
        	String option = input.nextLine().trim().toLowerCase();
        	
        	switch(option) {
        	case "1": //New Dog Intake
        		intakeNewDog(input);
        		break;
        		
        	case "2": //New Monkey Intake
        		intakeNewMonkey(input);
        		break;
        		
        	case "3": //Reserve Animal
        		reserveAnimal(input);
        		break;
        		
        	case "4": //Print list of all dogs
        		printAnimals("dog");
        		break;
        		
        	case "5": //Print list of all monkeys
        		printAnimals("monkey");
        		break;
        		
        	case "6": //Print list of all available (non-reserved) animals
        		printAnimals("available");
        		break;
        		
        	case "q": //Quit
        		acceptingInput = false;
        		break;
        		
        	default: //Feedback stating the user input does not match menu options
        		System.out.println("Invalid entry. Please enter a valid menu option.");
        		break;
        	}
        }while(acceptingInput);

    }

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }


    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true, "Canada");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
    }


    // Adds monkeys to a list for testing
    //Optional for testing
    public static void initializeMonkeyList() {
    	Monkey monkey1 = new Monkey("Bella", "Guenon", "female", "3", "7.9", "20", "16", "12", "05-21-2021", "Canada", "Phase I", false, "Canada");
    	Monkey monkey2 = new Monkey("Edward", "Squirrel monkey", "male", "4", "2.7", "12.5", "9", "16", "03-13-2020", "United States", "Phase III", false, "United States");
    	Monkey monkey3 = new Monkey("Jacob", "Tamarin", "male", "4", "1.6", "9", "7", "1", "01-15-2020", "United States", "in service", false, "United States");
    	
    	monkeyList.add(monkey1);
    	monkeyList.add(monkey2);
    	monkeyList.add(monkey3);
    }


    // Completed intakeNewDog method
    // This adds new dogs to "dogList"
    public static void intakeNewDog(Scanner scanner) {
        System.out.println("What is the dog's name?");
        String name = scanner.nextLine();
        
        //Ensure dog is not already in dogList
        for(Dog dog: dogList) {
            if(dog.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis dog is already in our system\n\n");
                return; //returns to menu
            }
        }

        // code to instantiate a new dog and add it to the appropriate list
        //This code gathers information about the new dog
        System.out.println("Enter " + name + "'s breed:");
        String breed = scanner.nextLine().trim();
        
        System.out.println("Enter " + name + "'s gender: (\"male\", \"female\")");
        String gender = scanner.nextLine().trim().toLowerCase();
        
        System.out.println("Enter " + name + "'s age in years: ");
        String age = scanner.nextLine().trim();
        
        System.out.println("Enter " + name + "'s weight in pounds: ");
        String weight = scanner.nextLine().trim();
        
        System.out.println("Enter the date " + name + " was acquired into your care: (MM-DD-YYYY)");
        String acquisitionDate = scanner.nextLine().trim();
        
        System.out.println("Enter the country where " + name + " was acquired: ");
        String acquisitionCountry = scanner.nextLine().trim();
        
        System.out.println("Enter " + name + "'s current training status: (\"intake\", \"in service\", \"phase I/II/III/IV/V\", \"farm\")");
        String trainingStatus = scanner.nextLine().trim();
        
        System.out.println("Is " + name + " currently reserved? (Y/N)");
        boolean reserved = scanner.nextLine().trim().equalsIgnoreCase("Y");
        
        System.out.println("Enter " + name + "'s service country: ");
        String inServiceCountry = scanner.nextLine().trim();
        
        //Sets data for all attributes
        Dog newDog = new Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry);
        
        //Adds new dog to dog ArrayList
        dogList.add(newDog);  
        
    }

        // Completed intakeNewMonkey
		//Instantiate and add the new monkey to the monkey ArrayList

        public static void intakeNewMonkey(Scanner scanner) {
        	
        	//Prompt user for input on name
            System.out.println("Enter the monkey's name: ");
            String name = scanner.nextLine().trim();
            
            //Validate user input on monkey name
            //display appropriate feedback when a monkey is already registered in the system
            for(Monkey monkey : monkeyList)
            	if (monkey.getName().equalsIgnoreCase(name)) {
            		System.out.println("\n\nThis monkey is already registered in our system.\n\n");
            		return;
            	}
            
       //register a new monkey and add it to the correct list
            boolean invalidSpecies = true;
            
            //Prompt user for input on species
            //Validate user input for monkey species
            String species;
            do {
            	System.out.println("Enter " + name + "'s species: ");
            	species = scanner.nextLine().trim();
            	
            	for(String validSpecies : Monkey.VALID_SPECIES)
            		if(species.equalsIgnoreCase(validSpecies))
            			invalidSpecies = false;
            	
            	//Display appropriate feedback for invalid species input
            	if(invalidSpecies)
            		System.out.println("Invalid species entry.");
            }while(invalidSpecies);
            
            //Prompting user for information on new monkey
            System.out.println("Enter " + name + "'s gender: (\"male\", \"female\")");
            String gender = scanner.nextLine().trim().toLowerCase();
            
            System.out.println("Enter " + name + "'s age (in years): ");
            String age = scanner.nextLine().trim();
            
            System.out.println("Enter " + name + "'s weight (in pounds): ");
            String weight = scanner.nextLine().trim();
            
            System.out.println("Enter " + name + "'s height (head to toe) in inches: ");
            String height = scanner.nextLine().trim();
            
            System.out.println("Enter " + name + "'s body length (head to pelvis) in inches: ");
            String bodyLength = scanner.nextLine().trim();
            
            System.out.println("Enter " + name + "'s tail length (base to tip) in inches: ");
            String tailLength = scanner.nextLine().trim();
            
            System.out.println("Enter the date " + name + " was acquired into your care: (MM-DD-YYYY)");
            String acquisitionDate = scanner.nextLine().trim();
            
            System.out.println("Enter the country where " + name + " was acquired: ");
            String acquisitionCountry = scanner.nextLine().trim();
            
            System.out.println("Enter " + name + "'s current training status: (\"intake\", \"in service\", \"phase I/II/III/IV/V\", \"farm\")");
            String trainingStatus = scanner.nextLine().trim();
            
            System.out.println("Is " + name + " currently reserved? (Y/N)");
            boolean reserved = scanner.nextLine().trim().equalsIgnoreCase("Y");
            
            System.out.println("Enter " + name + "'s current service country: ");
            String inServiceCountry = scanner.nextLine().trim();
            
            //Sets data for all attributes
            Monkey newMonkey = new Monkey(name, species, gender, age, weight, height, bodyLength, tailLength, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry);
            
            //add new monkey to monkeyList 
            monkeyList.add(newMonkey);
        }

        // Completed reserveAnimal
        // Find and reserve the animal by animal type and in service country
        public static void reserveAnimal(Scanner scanner) {
            System.out.println("What type of animal would you like to reserve? (\"dog\", \"monkey\")");
            String animalType = scanner.nextLine().trim();
            
            System.out.println("What country will the animal be in service?");
            String animalServiceCountry = scanner.nextLine().trim();
            
            //If user requests a dog reservation:
            //sort through all available dogs
            if(animalType.equalsIgnoreCase("dog"))
            	for(Dog dog : dogList)
            		if(true
            			&& dog.getInServiceLocation().equalsIgnoreCase(animalServiceCountry)
            			&& !dog.getReserved()
            			) {
            				dog.setReserved(true);
            				dog.setInServiceCountry(animalServiceCountry);
            				
            				System.out.println(dog.getName() + " has been reserved!");
            				return;
            			}
            //Sort through all available monkeys
            if(animalType.equalsIgnoreCase("monkey"))
            	for(Monkey monkey : monkeyList)
            		if(true
            				&& monkey.getInServiceLocation().equalsIgnoreCase(animalServiceCountry)
            				&& !monkey.getReserved()
            				) {
            			monkey.setReserved(true);
            			monkey.setInServiceCountry(animalServiceCountry);
            			
            			System.out.println(monkey.getName() + " has been reserved!");
            			return;
            		}
            System.out.println("Unable to reserve a " + animalType + " from " + animalServiceCountry + " at this time.");

        }

        // Complete printAnimals
        // Included is the animal name, status, acquisition country and if the animal is reserved.
        public static void printAnimals(String outputType) {
            System.out.printf("%-8.15s\t| %-1.15s\t| %-1.15s\t| %s%n%n", "Name", "Status", "Acq. Country", "Reserved");
            
            //Three different outputs for printAnimals() method
            switch(outputType) {
            case "dog": //List of all dogs
            	for(Dog dog : dogList) {
            		String name = dog.getName();
            		String status = dog.getTrainingStatus();
            		String acquisitionCountry = dog.getAcquisitionLocation();
            		boolean reserved = dog.getReserved();
            		
            		System.out.printf("%-8.15s\t| %-1.15s\t| %-1.15s\t| %s%n", name, status, acquisitionCountry, reserved);
            	}
            	break;
            case "monkey": //List of all monkeys
            	for(Monkey monkey : monkeyList) {
            		String name = monkey.getName();
            		String status = monkey.getTrainingStatus();
            		String acquisitionCountry = monkey.getAcquisitionLocation();
            		boolean reserved = monkey.getReserved();
            		
            		System.out.printf("%-8.15s\t| %-1.15s\t| %-1.15s\t| %s%n", name, status, acquisitionCountry, reserved);
            	}
            	break;
            case "available": //Print all available / non-reserved dogs
            	for(Dog dog : dogList) {
            		String name = dog.getName();
            		String status = dog.getTrainingStatus();
            		String acquisitionCountry = dog.getAcquisitionLocation();
            		boolean reserved = dog.getReserved();
            		
            		boolean available = !reserved && status.equalsIgnoreCase("in service");
            		if(!available)
            			continue;
            		
            		System.out.printf("%-8.15s\t| %-1.15s\t| %-1.15s\t| %s%n", name, status, acquisitionCountry, reserved);
            	}
            	
            	//Print all available / non-reserved monkeys
            	for(Monkey monkey : monkeyList) {
            		String name = monkey.getName();
            		String status = monkey.getTrainingStatus();
            		String acquisitionCountry = monkey.getAcquisitionLocation();
            		boolean reserved = monkey.getReserved();
            		
            		boolean available = !reserved && status.equalsIgnoreCase("in service");
            		if(!available)
            			continue;
            		
            		System.out.printf("%-8.15s\t| %-1.15s\t| %-1.15s\t| %s%n", name, status, acquisitionCountry, reserved);
            	}
            	break;
            }

        }
}

/*
 * CS-499 Enhancement Plan Notes
 *   - Replace the console menu with a JavaFX GUI controller
 *   - Add robust input validation and exception handling
 *   - Refactor repeated blocks into reusable methods
 *   - Connect to a persistence mechanism (such as JSON or a database)
 */
