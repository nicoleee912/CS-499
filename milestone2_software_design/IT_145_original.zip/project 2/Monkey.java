/*
 * CS-499 Computer Science Capstone
 * Artifact Category: Software Engineering and Design
 * Original Course: IT-145 Foundations in Application Development
 *
 * File: Monkey.java
 * Description:
 *   Monkey subclass of RescueAnimal representing primate rescue animals in the
 *   system. Used to demonstrate inheritance and polymorphism in the project.
 *
 * Code Review Focus:
 *   - Alignment with the RescueAnimal class and Dog subclass
 *   - Consistency of field naming and constructor patterns
 *   - Potential duplication that could be pushed up into the base class
 */

//Inherit from RescueAnimal
public class Monkey extends RescueAnimal {
	//Instance variables
	private String species;
	private String height;
	private String tailLength;
	private String bodyLength;
	
	//Set valid species
	public final static String[] VALID_SPECIES = {
			"Capuchin",
			"Guenon",
			"Macaque",
			"Marmoset",
			"Squirrel monkey",
			"Tamarin"
	};
	
	//Constructor to initialize values for all monkey attributes
	public Monkey(
			String name, String species, String gender, String age,
			String weight, String height, String bodyLength, String tailLength,
			String acquisitionDate, String acquisitionCountry, String trainingStatus,
			boolean reserved, String inServiceCountry
			) {
		setName(name);
		setSpecies(species);
		setGender(gender);
		setAge(age);
		setWeight(weight);
		setHeight(height);
		setBodyLength(bodyLength);
		setTailLength(tailLength);
		setAcquisitionDate(acquisitionDate);
		setAcquisitionLocation(acquisitionCountry);
		setTrainingStatus(trainingStatus);
		setReserved(reserved);
		setInServiceCountry(inServiceCountry);
	}
	
	//Accessor methods
	public String getSpecies() {
		return species;
	}
	
	public String getHeight() {
		return height;
	}
	
	public String getTailLength() {
		return tailLength;
	}
	
	public String getBodyLength() {
		return bodyLength;
	}
	
	//Mutator methods
	public void setSpecies(String monkeySpecies) {
		species = monkeySpecies;
	}
	
	public void setHeight(String monkeyHeight) {
		height = monkeyHeight;
	}
	
	public void setTailLength(String monkeyTailLength) {
		tailLength = monkeyTailLength;
	}
	
	public void setBodyLength(String monkeyBodyLength) {
		bodyLength = monkeyBodyLength;
	}
}

/*
 * CS-499 Enhancement Plan Notes
 *   - Look for opportunities to move common code into RescueAnimal
 *   - Apply the same validation and commenting conventions used in Dog
 */
