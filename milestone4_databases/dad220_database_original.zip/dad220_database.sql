/*****************************************************************************************
    CS 499 Computer Science Capstone
    Artifact Category: Databases
    Original Course: DAD 220 Databases

    File: dad220_databases.sql
    Description:
      • includes tables (Customers, Products, Orders, OrderLine, Inventory, RMA)
      • Sample data I used for analysis reports in the course
      • Example queries I wrote for return percentages and customer activity
      • A foundation for the enhancements I will implement in CS 499

    Code Review Focus (Checklist):
      • Structure: clarity of adapter methods and view binding
      • Loops and branches: how item collections are traversed
*****************************************************************************************/


/******************************
    CREATE DATABASE
******************************/
CREATE DATABASE IF NOT EXISTS quantigration;
USE quantigration;


/******************************
    CUSTOMERS TABLE
******************************/
CREATE TABLE Customer (
    customer_id      INT AUTO_INCREMENT PRIMARY KEY,
    first_name       VARCHAR(50)  NOT NULL,
    last_name        VARCHAR(50)  NOT NULL,
    email            VARCHAR(100) NOT NULL UNIQUE,
    phone            VARCHAR(25),
    street_address   VARCHAR(100),
    city             VARCHAR(50),
    state_code       CHAR(2),
    postal_code      VARCHAR(10),
    created_at       DATETIME DEFAULT CURRENT_TIMESTAMP
);


/******************************
    PRODUCTS TABLE
******************************/
CREATE TABLE Product (
    product_id       INT AUTO_INCREMENT PRIMARY KEY,
    sku              VARCHAR(50)  NOT NULL UNIQUE,
    product_name     VARCHAR(100) NOT NULL,
    description      VARCHAR(255),
    unit_price       DECIMAL(10,2) NOT NULL,
    active           TINYINT(1) DEFAULT 1
);


/******************************
    ORDER HEADER TABLE
******************************/
CREATE TABLE OrderHeader (
    order_id         INT AUTO_INCREMENT PRIMARY KEY,
    customer_id      INT NOT NULL,
    order_date       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status           VARCHAR(20) NOT NULL DEFAULT 'Pending',
    total_amount     DECIMAL(10,2) NOT NULL DEFAULT 0,

    CONSTRAINT fk_order_customer
        FOREIGN KEY (customer_id)
        REFERENCES Customer(customer_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
);


/******************************
    ORDER LINE ITEMS TABLE
******************************/
CREATE TABLE OrderLine (
    order_line_id    INT AUTO_INCREMENT PRIMARY KEY,
    order_id         INT NOT NULL,
    product_id       INT NOT NULL,
    quantity         INT NOT NULL,
    unit_price       DECIMAL(10,2) NOT NULL,
    line_total       DECIMAL(10,2) NOT NULL,

    CONSTRAINT fk_line_order
        FOREIGN KEY (order_id)
        REFERENCES OrderHeader(order_id)
        ON DELETE CASCADE,

    CONSTRAINT fk_line_product
        FOREIGN KEY (product_id)
        REFERENCES Product(product_id)
        ON DELETE RESTRICT
);


/******************************
    INVENTORY TABLE
******************************/
CREATE TABLE Inventory (
    inventory_id     INT AUTO_INCREMENT PRIMARY KEY,
    product_id       INT NOT NULL,
    quantity_on_hand INT NOT NULL,
    reorder_point    INT NOT NULL,
    last_updated     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_inventory_product
        FOREIGN KEY (product_id)
        REFERENCES Product(product_id)
        ON DELETE CASCADE
);


/******************************
    RMA (RETURNS) TABLE
******************************/
CREATE TABLE RMA (
    rma_id           INT AUTO_INCREMENT PRIMARY KEY,
    order_id         INT NOT NULL,
    product_id       INT NOT NULL,
    rma_date         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reason           VARCHAR(255),
    quantity         INT NOT NULL,
    status           VARCHAR(20) NOT NULL DEFAULT 'Open',

    CONSTRAINT fk_rma_order
        FOREIGN KEY (order_id)
        REFERENCES OrderHeader(order_id)
        ON DELETE CASCADE,

    CONSTRAINT fk_rma_product
        FOREIGN KEY (product_id)
        REFERENCES Product(product_id)
        ON DELETE RESTRICT
);


/******************************
    INDEXES (Enhancement-Friendly)
******************************/
CREATE INDEX idx_order_customer ON OrderHeader(customer_id);
CREATE INDEX idx_line_product ON OrderLine(product_id);
CREATE INDEX idx_rma_status   ON RMA(status);


/******************************
    SAMPLE DATA
******************************/
INSERT INTO Customer (first_name, last_name, email, city, state_code, postal_code)
VALUES
('Alice', 'Rivera', 'alice@example.com', 'Orlando', 'FL', '32801'),
('Brian', 'Nguyen', 'brian@example.com', 'Tampa',   'FL', '33601');

INSERT INTO Product (sku, product_name, description, unit_price)
VALUES
('SKU-1001', '4K Monitor', '27 inch 4K display', 329.99),
('SKU-2002', 'Mechanical Keyboard', 'RGB backlit keyboard', 129.99);

INSERT INTO OrderHeader (customer_id, order_date, status, total_amount)
VALUES
(1, NOW(), 'Shipped', 459.98);

INSERT INTO OrderLine (order_id, product_id, quantity, unit_price, line_total)
VALUES
(1, 1, 1, 329.99, 329.99),
(1, 2, 1, 129.99, 129.99);

INSERT INTO Inventory (product_id, quantity_on_hand, reorder_point)
VALUES
(1, 50, 10),
(2, 75, 15);

INSERT INTO RMA (order_id, product_id, quantity, reason, status)
VALUES
(1, 2, 1, 'Defective keys', 'Open');


/******************************
    EXAMPLE QUERIES
******************************/

-- Basic JOIN showing order details
SELECT 
    oh.order_id,
    c.first_name,
    c.last_name,
    p.product_name,
    ol.quantity,
    ol.line_total
FROM OrderHeader oh
JOIN Customer c      ON oh.customer_id = c.customer_id
JOIN OrderLine ol    ON oh.order_id = ol.order_id
JOIN Product p       ON ol.product_id = p.product_id;

-- Return percentage by product
SELECT 
    p.product_name,
    COUNT(r.rma_id) AS total_returns,
    (COUNT(r.rma_id) / (SELECT COUNT(*) FROM OrderLine WHERE product_id = p.product_id)) * 100 
      AS return_percentage
FROM Product p
LEFT JOIN RMA r ON p.product_id = r.product_id
GROUP BY p.product_id;

-- Low stock alert example
SELECT 
    p.product_name,
    i.quantity_on_hand,
    i.reorder_point
FROM Inventory i
JOIN Product p ON i.product_id = p.product_id
WHERE i.quantity_on_hand < i.reorder_point;


/*****************************************************************************************
    Enhancement Area Placeholder
    (To be implemented in CS 499)
    
    Planned Enhancements:
      • Trigger to update order status when RMA logged
      • Stored procedure to calculate return percentages
      • Additional normalization and constraints
      • Indexing for better performance
*****************************************************************************************/
